<?php
namespace FMU;

use FMU\Import\Iterator\FieldValideIterator;
use FMU\Import\Iterator\LineFilterIterator;
use FMU\Import\Iterator\LineToConfigIterator;
use FMU\Import\Iterator\FileIterator;

class Import
{

    private $fileIterator;

    private $config;

    public function __construct($file_name, \FMU\Import\Config $config)
    {
        $this->fileIterator = new FileIterator($file_name);
        $this->config = $config;
    }

    public function parseTest()
    {
        $lci = new LineToConfigIterator($this->fileIterator, $this->config);
        $lvi = new LineFilterIterator($lci);
        
        foreach ($lci as $value) {
            if ($value) {
               echo $value->validateLine();
            }
        }
    }
}
?>