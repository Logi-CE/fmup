<?php
/*
namespace FMU\Import\Iterator;

class FieldValideIterator extends \IteratorIterator
{

    private $config;

    public function __construct(\Iterator $fIterator)
    {
        parent::__construct($fIterator);
    }

    public function current()
    {
        $this->config = $this->getInnerIterator()->current();
        return $this->config;
    }

    public function validateAllField()
    {
        $errors = array();
        if (count($liste_champ) > 1) {
            foreach ($this->config->getListeField() as $key => $field) {
                $field->formatField();
                $valid_field = $field->validateField();
                if (! $valid_field) {
                    $errors[$field->getName()] = "\n Attention : Le champ " . $field->getName() . " est non valide";
                }
                // Debug de test
                echo $key . " \t" . $field->getName() . " \t" . $field->getValue() . " \t \n";
            }
            return $errors;
        }
    }
}*/
//Delete ?
