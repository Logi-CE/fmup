<?php
namespace FMU\Import\Iterator;

class LineToConfigIterator extends \IteratorIterator
{

    private $config;

    public function __construct(\Iterator $fIterator, \FMU\Import\Config $config)
    {
        parent::__construct($fIterator);
        $this->config = $config;
    }

    public function current()
    {
        $liste_champ = explode(";", $this->getInnerIterator()->current());
        if (count($liste_champ) > 1) {
            $valid = true;
            foreach ($liste_champ as $key => $champ) {
                $field = $this->config->getField($key);
                $field->setValue($champ);
            }
            return $this->config;
        } else {
            return null;
        }
    }
}