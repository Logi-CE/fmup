<?php
namespace FMU\Import\Iterator;

use FMU\Import\Config;

class LineFilterIterator extends \FilterIterator
{

    public function __construct(\Iterator $iterator)
    {
        parent::__construct($iterator);
    }

    private $config;

    public function current()
    {
        return $this->getInnerIterator()->current();
    }
    
    public function accept()
    {
        $config = $this->getInnerIterator()->current();
        if (!$config) {
            return false;
        }
        return $config->validateLine();
    }

}