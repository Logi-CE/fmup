<?php
namespace FMU\Import\Config\Field;

interface Formatter
{

    public function format($value);
}