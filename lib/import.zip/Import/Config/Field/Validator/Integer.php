<?php
namespace FMU\Import\Config\Field\Validator;

use FMU\Import\Config\Field\Validator;

class Integer implements Validator
{

    public function validate($value)
    {
        $valid = true;
        if (\Is::integer($value)===false) {
            $valid = false;
        }
        return $valid;
    }
}