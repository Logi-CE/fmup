<?php
namespace FMU\Import\Config\Field\Validator;

use FMU\Import\Config\Field\Validator;

class Email implements Validator
{

    public function validate($value)
    {
        $valid = true;
        if (! \Is::courriel($value)) {
            $valid = false;
        }
        return $valid;
    }
}