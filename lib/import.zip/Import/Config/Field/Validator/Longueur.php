<?php
namespace FMU\Import\Config\Field\Validator;

use FMU\Import\Config\Field\Field;

class Longueur implements Validator
{

    private $longueur;

    public function __construct($longueur)
    {
        $this->longueur = $longueur;
    }

    public function validate($value)
    {
        $valid = true;
        if (strlen($value) > $this->longueur) {
            $valid = false;
        }
        return $valid;
    }
}