<?php
namespace FMU\Import\Config\Field\Validator;

use FMU\Import\Config\Field\Validator;

class Required implements Validator
{

    public function validate($value)
    {
        $valid = true;
        if ($value === false || $value === null || $value === "") {
            $valid = false;
        }
        return $valid;
    }
}