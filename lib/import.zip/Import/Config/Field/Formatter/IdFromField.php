<?php
namespace FMU\Import\Config\Field\Formatter;

use FMU\Import\Config\Field\Formatter;

class IdFromField implements Formatter
{

    private $champ_origine;

    private $table_origine;

    public function __construct($champ_origine, $table_origine)
    {
        $this->champ_origine = $champ_origine;
        $this->table_origine = $table_origine;
    }

    public function format($value)
    {
        if ($value == "") {
            return "Champ vide";
        } else {
            $sql = "
            SELECT id
            FROM " . $this->table_origine . "
            WHERE " . $this->champ_origine . " LIKE '%" . $value . "%'    
            ";
            $result = \Model::getDb()->requete($sql);
            if ($result) {
                return $result[0]['id'];
            } else {
                return $this->getMessageErreur($value);
            }
        }
    }

    public function getMessageErreur($value)
    {
        return "Aucune correspondance n'a été trouvé pour le champ : " . $this->champ_origine . " de la table : " . $this->table_origine . " pour la valeur : " . $value;
    }
}
