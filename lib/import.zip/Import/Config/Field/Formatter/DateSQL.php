<?php
namespace FMU\Import\Config\Field\Formatter;

use FMU\Import\Config\Field\Formatter;

class DateSQL implements Formatter
{

    public function format($value)
    {
        if ($value == "") {
            return "Champ vide";
        } else {
            $result = \Date::frToUk($value);
            if ($result) {
                echo $value . " " . $result . "\n";
                return $result;
            } else {
                return $this->getMessageErreur($value);
            }
        }
    }

    public function getMessageErreur($value)
    {
        return "La valeur  " . $value . "n'est pas convertible \n";
    }
}
