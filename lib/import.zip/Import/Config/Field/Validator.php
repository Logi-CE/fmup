<?php
namespace FMU\Import\Config\Field;

interface Validator
{

    public function validate($value);
    
    /*
     * les required sont à voir niveau config
     * envoi uniquement de la valeur aux validator
     * on doit add le bon validator
     * à automatiser via l'attribut type de field
     *
     */
}