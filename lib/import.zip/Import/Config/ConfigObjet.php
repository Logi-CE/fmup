<?php
namespace FMU\Import\Config;

class ConfigObjet
{

    /**
     * Nom de la classe de l'objet
     *
     * @var String
     */
    private $nom_objet;

    /**
     *
     * @var integer
     */
    private $priorite;

    /**
     *
     * @var string
     */
    private $id_necessaire = null;

    /**
     *
     * @var string
     */
    private $nom_attribut;

    /**
     *
     * @var string
     */
    private $statut = "";

    /**
     * liste des index correspondant aux champs associés à l'objet
     *
     * @var Integer
     */
    private $liste_index_champ = array();

    /*
     * ***************************
     * GETTERS
     * ***************************
     */
    public function getListeIndexChamp()
    {
        return $this->liste_index_champ;
    }

    public function getPriorite()
    {
        return $this->priorite;
    }

    public function getNomObjet()
    {
        return $this->nom_objet;
    }

    public function getIdNecessaire()
    {
        return $this->id_necessaire;
    }

    public function getStatut()
    {
        return $this->statut;
    }

    public function getNomAttribut()
    {
        return $this->nom_attribut;
    }

    /*
     * ***************************
     * SETTERS
     * ***************************
     */
    public function setStatutInsertion()
    {
        $this->statut = "insert";
    }

    public function setStatutMaj()
    {
        $this->statut = "update";
    }

    public function setIdNecessaire(string $id_necessaire)
    {
        $this->id_necessaire = $id_necessaire;
    }

    public function setNomObjet($nom)
    {
        $this->nom_objet = $nom;
    }

    public function addIndex($index)
    {
        array_push($this->liste_index_champ, $index);
    }

    /**
     *
     * @param string $nom_objet
     *            : Nom de l'objet présent dans le model
     * @param integer $priorite
     *            : Niveau de priorité et de dépendance
     * @param string $id_necessaire
     *            : Nom de l'objet dont l'id est necessaire pour remplir l'objet this
     */
    public function __construct($nom_objet, $priorite, $id_necessaire = "")
    {
        $this->nom_objet = $nom_objet;
        $this->priorite = $priorite;
        $this->id_necessaire = $id_necessaire;
        $this->nom_attribut = "id_" . \String::to_Case($id_necessaire);
    }
}