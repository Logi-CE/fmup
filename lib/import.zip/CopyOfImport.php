<?php
//namespace FMU;

class Import
{

    private $fileIterator;

    private $config;

    public function __construct($file_name, \FMU\Import\Config $config = null)
    {
        $this->fileIterator = new \FMU\Import\FileIterator($file_name);
        $this->config = $config;
    }

    public function parseTest()
    {
        foreach ($this->fileIterator as $value) {
            if (! empty($value)) {
                $ligne = explode(";", $value);
                //récupération et validation des champs 
                $valid = true;
                foreach ($ligne as $key => $champ) {
                    $field = $this->config->getField($key);
                    $valid_field = $field->setValue($champ);
                    if (!$valid_field) $valid = false;
                    echo $key . " \t" . $field->getName() . " \t" . $champ . " \t" . ($valid_field!==false ? "champ OK" : "champ mort") ."\n";
                }
                //vérification de la ligne
                $required_valid = true;
                foreach ($this->config->getListeRequired() as $required_index){
                    $field_to_test = $this->config->getField($required_index);
                    if ($field_to_test && ($field_to_test->getValue()===null || $field_to_test->getValue()=="")) {
                        $required_valid = false;
                    }
                }
                if(!$required_valid){
                    echo "Ligne non-valide : un champ obligatoire est manquant \n";
                } elseif (!$valid) {
                    echo "Attention un champ est non valide\n";
                } else {
                    $liaison = new \FMU\Import\LiaisonBase($this->config);
                }
            }
        }
    }
}
?>